# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""

'''
Implement the two layer network for m-samples, n-features as we discussed in class (both FP and BP) and for N layers in the hidden layer.
Split the data (you can use the log. reg. data or any other one) and train your network with 70% of the data. 
Test your network with the test data. Report the evaluation metrics for varying number of layers in the network.
Commented out IPython magic to ensure Python compatibility.
'''
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def Sigmoid(z):
  return 1/(1+np.exp(-z))



def Defi_Str(X, Y, h):
  input_unit = X.shape[0] 
  hidden_unit = h 
  output_unit = Y.shape[0] 
  return (input_unit, hidden_unit, output_unit)

def Para_Init(input_unit, hidden_unit, output_unit):
  np.random.seed(2) 
  W1 = np.random.randn(hidden_unit, input_unit)*0.01
  b1 = np.zeros((hidden_unit, 1))
  W2 = np.random.randn(output_unit, hidden_unit)*0.01
  b2 = np.zeros((output_unit, 1))
  parameters = {"W1": W1,"b1": b1,"W2": W2,"b2": b2}
  return parameters



def For_Propa(X, parameters):
  W1 = parameters['W1']
  b1 = parameters['b1']
  W2 = parameters['W2']
  b2 = parameters['b2']
  Z1 = np.dot(W1, X) + b1
  A1 = np.tanh(Z1)
  Z2 = np.dot(W2, A1) + b2
  A2 = Sigmoid(Z2)
  outputs = {"Z1": Z1,"A1": A1,"Z2": Z2,"A2": A2}  
  return A2, outputs

def Cross_Entropy_Cost(A2, Y, parameters):
  m = Y.shape[1] 
  logprobs = np.log(A2)*Y + (1-Y)*np.log(1-A2)
  cost = - np.sum(logprobs)/m
  cost = float(np.squeeze(cost))                                 
  return cost

def Back_Propa(parameters, outputs, X, Y):
  m = X.shape[1]    
  W1 = parameters['W1']
  W2 = parameters['W2']
  A1 = outputs['A1']
  A2 = outputs['A2']
  dZ2 = A2-Y
  dW2 = (1/m)*dZ2@A1.T
  db2 = (1/m) * np.sum(dZ2, axis=1, keepdims=True)
  dZ1 = (W2.T@dZ2)*(1 - A1**2)
  dW1 = (1/m)*dZ1@X.T
  db1 = (1/m)*np.sum(dZ1, axis=1, keepdims=True)
  gradients = {"dW1": dW1, "db1": db1, "dW2": dW2,"db2": db2} 
  return gradients

def Grad_Desce(parameters, gradients, learning_rate = 0.01):
  W1 = parameters['W1']
  b1 = parameters['b1']
  W2 = parameters['W2']
  b2 = parameters['b2']
  dW1 = gradients['dW1']
  db1 = gradients['db1']
  dW2 = gradients['dW2']
  db2 = gradients['db2']    
  W1 = W1 - learning_rate * dW1
  b1 = b1 - learning_rate * db1
  W2 = W2 - learning_rate * dW2
  b2 = b2 - learning_rate * db2 
  parameters = {"W1": W1, "b1": b1,"W2": W2,"b2": b2} 
  return parameters

def Neural_Network_Model(X, Y, hidden_unit, num_iterations = 1000):
  np.random.seed(3)
  input_unit = Defi_Str(X, Y, hidden_unit)[0]
  output_unit = Defi_Str(X, Y, hidden_unit)[2]
  parameters = Para_Init(input_unit, hidden_unit, output_unit)
  W1 = parameters['W1']
  b1 = parameters['b1']
  W2 = parameters['W2']
  b2 = parameters['b2']
  for i in range(0, num_iterations):
    A2, outputs = For_Propa(X, parameters)
    cost = Cross_Entropy_Cost(A2, Y, parameters)
    gradients = Back_Propa(parameters, outputs, X, Y)
    parameters = Grad_Desce(parameters, gradients)    
  return parameters

df=pd.read_csv("Logistic_regression_ls.csv")
X=df[["x1","x2"]].to_numpy()
Y=df["label"].to_numpy()

plt.scatter(X[:, 0], X[:, 1], alpha=0.2,c=Y, cmap='viridis')

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=42)
X_train = X_train.T
Y_train = Y_train.reshape(1, Y_train.shape[0])
X_test = X_test.T
Y_test = Y_test.reshape(1, Y_test.shape[0])
print ('Train X Shape:', X_train.shape)
print ('Train Y Shape:', Y_train.shape)
print ('Number of training examples=',X_train.shape[1])
print ('Test X Shape:', X_test.shape)

parameters = Neural_Network_Model(X_train, Y_train, 5, num_iterations=10000)

def Pred(parameters, X):
  A2, outputs = For_Propa(X, parameters)
  predictions = np.round(A2)
  return predictions

Y_pred = Pred(parameters, X_test)
Y_test.shape

def Evalu_Metr(Y_test,Y_pred):
  m=Y_test.shape[1]
  tp=0
  tn=0
  fp=0
  fn=0
  for i in range(m):
    if(Y_pred[0,i]==0 and Y_test[0,i]==0):
      tn+=1
    elif(Y_pred[0,i]==1 and Y_test[0,i]==1):
      tp+=1
    elif(Y_pred[0,i]==1 and Y_test[0,i]==0):
      fp+=1
    else:
      fn+=1
  acc=(tp+tn)/(tp+tn+fp+fn)
  pre=tp/(tp+fp)
  rec=tp/(tp+fn)
  f1=2*pre*rec/(pre+rec)

  return (acc,pre,rec,f1)

accuracy,precision,recall,f1_score=Evalu_Metr(Y_test,Y_pred)

print("Accuracy=",accuracy)
print("Precision=",precision)
print("Recall=",recall)
print("F1-Score=",f1_score)


for h in range(1,101):
  parameters = Neural_Network_Model(X_train, Y_train, h, num_iterations=1000)
  Y_pred = Pred(parameters, X_test)
  accuracy,precision,recall,f1_score=Evalu_Metr(Y_test,Y_pred)
  print("For {} neurons in hidden layer:".format(h))
  print("Accuracy=",accuracy)
  print("Precision=",precision)
  print("Recall=",recall)
  print("F1-Score=",f1_score)
  print()

