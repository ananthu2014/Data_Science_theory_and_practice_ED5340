# -*- coding: utf-8 -*-
"""
Created on Fri Sep 23 14:04:01 2022

@author: ananthu2014
"""
#1) Using line (unidirectional) search, for the function (w1 - 10 )^2 + (w2 - 10)^2
#find the minimum value along the direction (2, 5). You can assume the start point
#to be (2, 1). Plot the function and its contours along with the minimum value 
#in that direction. Is the search direction a gradient descent one? Comment on that
#as well.

def j(w1,w2):
   return (w1-10)**2 + (w2-10)**2


def newf(k):
     w1=2+2*k
     w2=1+5*k
     return j(w1,w2)

a = -100
b = 100
n = 1000
x = (b-a)/n
print('Initial value=', a)
print('Final value=', b)
print('No.of intermediate steps=', n)
print('Stepsize=', x)

for i in range(0, n+1):
    if newf(a+i*x) >= newf(a+(i+1)*x) and newf(a+(i+1)*x) <= newf(a+(i+2)*x):
        print(f"min between{a + (i*x)} and {a+(i+2)*x}")
        x1= a + (i*x)
        x2 = a + (i+2)*x
        break
    elif a+(i+2)*x <= b:
        continue
    else:
        print('there is no minimum between given intervals')
print(x1)
print(x2)

a=x1
b=x2
n=10**(-6)
wm=(a+b)/2
w1= a+((b-a)/4)
w2=b-((b-a)/4)  
while abs(b-a) < n:
  if newf(w1) < newf(wm):
    b=wm
    wm=w1
  elif newf(w2)<newf(wm):
      a=wm
      wm=w2
  else:
      a=w1
      b=w2      
print('The value obtained using interval halving is:',wm)

w1=2+2*wm
w2=1+5*wm
print('The coordinates which gives minimum value in the direction are;')
print('w1=',w1)
print('w2=',w2)
a=newf(wm)
print('The minimum value in the direction is :',a)



import matplotlib.pyplot as plt
import numpy as np


x = np.arange(-5, 5.0, 0.01)
y = np.arange(-5.0, 5.0, 0.01)
X,Y=np.meshgrid(x,y)
Z = (X-10) **2 + (Y-10) ** 2
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot_surface(X, Y, Z,color='blue')
ax.set_xlabel('w1 values')
ax.set_ylabel('w2 values')
ax.set_zlabel('J values')
ax.set_title('MULTIVARIABLE FUNCTION')
plt.show()
cp  = plt.contour(x, y, Z)
plt.clabel(cp, fontsize=8)
ax.set_xlabel('w1 VALUES')
ax.set_ylabel('w2 VALUES')
ax.set_zlabel('J VALUES')
ax.set_title('CONTOUR')

plt.plot([2,w1],[1,w2])
plt.plot(w1,w2,'rs')
plt.show()





    