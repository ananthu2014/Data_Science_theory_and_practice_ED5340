#!/usr/bin/env python
# coding: utf-8

# # (2) Using steepest gradient descent, find the local minimum for the function in the problem 1 (i.e. J(w1, w2) = (w1 - 10 )^2 + (w2 - 10)^2). While applying gradient descent, do the following (a) Fixing the value for alpha (b) use line search to determine the value for alpha. Plot the intermediate steps in the iteration to show the minimal point in that direction.




import numpy as np
import matplotlib.pyplot as plt




def mainfunction(w1,w2):
    J=(w1-10)**2+(w2-10)**2
    return J

def grad(w1,w2):
    return np.array([2*(w1-10),2*(w2-10)])



def gradient_Descent(alpha):
    i=0
    while True:
        if i==0:
            w=np.array([2,2])
        else:
            w=w-(alpha*grad(w[0],w[1]))
            if np.linalg.norm(grad(w[0],w[1]))<.001:
                return w
                break
        i+=1




print(f"The Minimum value of the function is {gradient_Descent(.01)}")




def grad(w1,w2):
    return np.array([2*(w1-10),2*(w2-10)])
def function(w,alpha):
    g=grad(w[0],w[1])
    J=((w[0]+alpha*(-1*g[0])-10))**2+(w[1]+alpha*(-1*g[1])-10)**2
    return J






def check_bracket(w1,w2,w3,w):
    JW1=function(w,w1)
    JW2=function(w,w2)
    JW3=function(w,w3)
    if JW1>JW2 and JW3>JW2:
        return True
    else:
        return False
def check_interval(error,b,a):
    L=b-a
    if abs(L)<error:
        return True
    else:
        return False




def bracket_method(a,b,n,w):
    i=0
    while True:
        if i==0:
            delta=(b-a)/n
            w1=a
            w2=w1+delta
            w3=w2+delta
        else:
            status=check_bracket(w1,w2,w3,w)
            if status:
                return w1,w3
            else:
                w1=w2
                w2=w3
                w3=w2+delta
            if w3>b:
                return "No minimum found in this method"
                break
        i+=1





def interval_halfing(a,b,error,w):
    i=0
    while True:
        w_m=(a+b)/2
        L=(b-a)
        w1=a+L/4
        w2=b-L/4
        JW1=function(w,w1)
        JW_M=function(w,w_m)
        JW2=function(w,w2)
        if JW1<JW_M:
            b=w_m
            w_m=w1
            status=check_interval(error,b,a)
            if status:
                return w1,w2,w_m
        else:
            if JW2<JW_M:
                a=w_m
                w_m=w2
                status=check_interval(error,b,a)
                if status:
                    return w1,w2,w_m
            else:
                a=w1
                b=w2
        i+=1



def gradient_Descent_withalpha():
    intermediate=[]
    i=0
    while True:
        if i==0:
            w=np.array([-1,2])
            intermediate.append(w)
        else:
            alpha1,alpha2=bracket_method(-1000,1000,100,w)
            value=interval_halfing(alpha1,alpha2,.001,w)
            alpha=value[2]
            w=w-(alpha*grad(w[0],w[1]))
            intermediate.append(w)
            if np.linalg.norm(grad(w[0],w[1]))<.001:
                return w,intermediate
                break
        i+=1




descent,inter=gradient_Descent_withalpha()
print(f"The Minimum of the function with variable learning rate is{descent} ")
for i in range(len(inter)):
    if i<1:
        plt.plot([inter[i-1][0],inter[i][0]],[inter[i-1][1],inter[i][1]],'rs-')




w1=np.linspace(-15,15,1000)
w2=np.linspace(-15,15,1000)
#w1=np.arange(-20,20,.1)
#w2=np.arange(-20,20,.1)
x,y=np.meshgrid(w1,w2)
z=mainfunction(x,y)
plt.figure(figsize=(10,10))
C=plt.contour(x,y,z)
plt.clabel(C,fontsize=10)
for i in range(len(inter)):
    if i<1:
        plt.plot([inter[i-1][0],inter[i][0]],[inter[i-1][1],inter[i][1]],'rs-')




inter[0]





