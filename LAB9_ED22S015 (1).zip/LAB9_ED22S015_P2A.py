# -*- coding: utf-8 -*-
"""
Created on Fri Sep 23 17:22:05 2022

@author: ananthu2014
"""

def j(w1,w2):
   return (w1-10)**2 + (w2-10)**2  

def gradj1(w1):
    gradw1 = 2*(w1-10)
    return gradw1

def gradj2(w2):
    gradw2 = 2*(w2-10)
    return gradw2

    
def newf(k):
     w1=2+2*k
     w2=1+5*k
     return j(w1,w2)

w1= 2
w2= 3
alpha = 0.01

for i in range (10000):       

 m=gradj1(w1)
 n=gradj2(w2)
 y = w1 - m*alpha
 z = w2 - n*alpha
 if gradj1(y) * gradj1(w1) < 10**(-6):
     break
 else:
     w1 = y
     w2 = z
print(w1)
print(w2)    
    
    