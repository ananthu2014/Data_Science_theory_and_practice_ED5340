# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 16:00:58 2022

@author: anant
"""
#interchanging row
matrix1=[[3,4,5],
         [7,4,3],
         [2,1,9]]
matrix2=[[2,7,9],
         [8,9,3],
         [2,7,9]]
r=int(input('Enter the row to be interchanged:'))

if r>len(matrix1):
    print('Invalid')
else:
    a=matrix1[r-1]
    matrix1[r-1]=matrix2[r-1]
    matrix2[r-1]=a
    print('The resultant matrices are :\n',matrix1,'\n',matrix2)

matrix1=[[3,4,5],
         [7,4,3],
         [2,1,9]]
matrix2=[[2,7,9],
         [8,9,3],
         [2,7,9]]


#interchanging column
k=int(input('Enter the column to be interchanged:'))
matrix1=[[3,4,5],
         [7,4,3],
         [2,1,9]]
matrix2=[[2,7,9],
         [8,9,3],
         [2,7,9]]

if k>len(matrix1):
    print('Invalid')
else:
 m1t = list(zip(*matrix1))
 m2t = list(zip(*matrix2))

 a=m1t[k-1]
 m1t[k-1]=m2t[k-1]
 m2t[k-1]=a

 m1t=zip(*m1t)
 m2t=zip(*m2t)
 print('column interchanged matrix1 is ;\n',*m1t)
 print('column interchanged matrix1 is ;\n',*m2t)