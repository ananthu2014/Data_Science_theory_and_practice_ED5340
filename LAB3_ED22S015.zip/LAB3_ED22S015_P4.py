# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 17:40:38 2022

@author: anant
"""

#methods that are applicable for lists but not for tuple


#tuple objects does not support item assignment and tuple is immutable whereas list is mutable
lst=[1,2,3,4,5]
lst[0]=3
print(lst)

tup=(1,2,3,4,5)
#tup[0]=3
#print(tup)


#we can remove items from list but we cannot remove items from tuple
lst.remove(2)
print(lst)
#tup.remove(3)
#print(tup)


#we cannot append things into tuple but possible in lists
lst1=[2,4,6,7,8,0]
a=3
lst1.append(a)
print(lst1)
tup1=(3,6,7,5,3,3)
tup1.append(a)
print(tup1)