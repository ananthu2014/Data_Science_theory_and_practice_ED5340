# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 13:29:05 2022

@author: anant
"""

#create 3 tuples for name,age and salary.Group them using indexing approach
# (with and wuthout comprehension) and then with zip function.Print the output as list.

name=('Ananthakrishnan','Dharani','Swapnil','Ramya')
age=(23,24,21,20)
salary=(150000,125000,175000,250000)

tups=[(name[i],age[i],salary[i]) for i in range(4)]
print(tups)
tups=tuple(tups)
print(tups)

#zip function
ite=zip(name,age,salary)
print(*ite)

for ite1 in zip(name,age,salary):
     print(*ite1)
     
lst2=[]    
for i in range(len(name)):
    lst2.append(name[i])
    lst2.append(salary[i])
    lst2.append(age[i])
print(lst2)
print(lst2[0:3])

print(lst2[3:6])
print(lst2[6:9])
print(lst2[9:12])

lst = [(name[i],age[i],salary[i]) for i in range(len(name))]
print(tuple(lst))



      




    