# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 14:45:24 2022

@author: anant
"""

#matrix operations

matrix1=[[3,4,5],
         [7,4,3],
         [2,1,9]]
matrix2=[[2,7,9],
         [8,9,3],
         [2,7,9]]

result=[[0,0,0],
        [0,0,0],
        [0,0,0]]

result=[matrix1[i][j]+matrix2[i][j] for i in range(3) for j in range(3)]
print('addition matrix is \n:',result[0:3] ,'\n',result[3:6],'\n',result[6:9])

result1=[matrix1[i][j]-matrix2[i][j] for i in range(3) for j in range(3)]
print('subtraction matrix is \n:',result1[0:3] ,'\n',result1[3:6],'\n',result1[6:9])

result2=[matrix1[i][i] for i in range(3)]
print('trace of matrix1 is :',result2[0]+result2[1]+result2[2])

result3=[matrix2[i][i] for i in range(3)]
print('trace of matrix2 is :',result3[0]+result3[1]+result3[2])

transpose1=[matrix1[j][i] for i in range(len(matrix1[0])) for j in range(len(matrix1))]
print('Transpose of matrix1 is \n',transpose1[0:3] ,'\n',transpose1[3:6],'\n',transpose1[6:9])

transpose2=[matrix2[j][i] for i in range(len(matrix2[0])) for j in range(len(matrix2))]
print('Transpose of matrix2 is \n',transpose2[0:3] ,'\n',transpose2[3:6],'\n',transpose2[6:9])



#using zip function

matrix1=[[3,4,5],
         [7,4,3],
         [2,1,9]]
matrix2=[[2,7,9],
         [8,9,3],
         [2,7,9]]

result=[[0,0,0],
        [0,0,0],
        [0,0,0]]

a=zip(*matrix1)
b=zip(*matrix2)
print('the transpose of the matrices are :\n',*a,'\n',*b)

mat1 = [[1,2,3],[5,6,7],[9,10,11]]
mat2 = [[12,11,10],[8,7,6],[4,3,2]]

result = [[mat1[i][j] + mat2[i][j]  for j in range
(len(mat1[0]))] for i in range(len(mat1))]

for r in result:
    print(r)

#(ii) Using Zip()
result1= [map(sum, zip(*t)) for t in zip(mat1, mat2)]
print(result)


#(ii) Using Zip()
mat3 = -1*mat2
result1= [map(sum, zip(*t)) for t in zip(mat1, mat3)]
print(result)



