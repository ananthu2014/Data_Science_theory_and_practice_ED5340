# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 14:08:10 2022

@author: anant
"""
import random
random_lst=[random.randint(10,100) for i in range(10)]
even_numbers=[]
odd_numbers=[]
for num in random_lst:
    if num%2==0:
        even_numbers.append(num)
    else:
        odd_numbers.append(num)
divisible_by_3=[]
for k in random_lst:
    if k%3==0:
        divisible_by_3.append(k)

print('The list of random numbers is :',random_lst)
print('Even numbers are:',even_numbers)
print('odd numbers are :',odd_numbers)
print('Numbers divisible by 3 are :',divisible_by_3)