# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 18:14:28 2022

@author: anant
"""

#PROBLEM1
#a)
lst1=[['A, 55, 8/3/90,XYZ, 5'],['B, 69, 9/12/58,ABC, 30L'],['B, 69, 9/12/58,ABC, 30L'], ['C, 90, 4/5/97,PQR, 20L'],['D, 60, 14/5/50,E, 200']]
print(lst1)
lst1.sort()
print(lst1)

#(b)  
# print(E, 75, 11/12/93,DFB, 5559)
i=input('Enter new bank account number=').split(',')
lst1.append(i)
print(lst1)
lst1.sort()
print(lst1)

#(c)
#Dharma, 12, 3/4/74, 30L
p=input('Enter the name to be removed=').split(',')
lst1.remove(p)
print(lst1)


#(d)
q=input('Enter the name that has to be inserted=').split(',')
lst1.insert(0,q)
print(lst1)

#(e) ne
lst2=[]
for d in lst1:
   if d not in lst2:
        lst2.append(d)
print(lst2)        
       
#(f)
lst2.sort()
print(lst2)


