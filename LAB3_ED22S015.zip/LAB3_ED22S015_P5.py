# -*- coding: utf-8 -*-
"""
Created on Fri Aug 12 14:35:46 2022

@author: anant
"""

#program to demonstrate tuple comprehension

tup1=(1,2,3,4,5,6,7,8,9,0,10,11,12,99)
tup2=tuple(num**2 for num in tup1)
print(tup1)
print(tup2)
print(type(tup2))
print(*tup2)
tup2=list(tup2)
print(tup2)
tup3=tuple(num for num in tup1 if num%2==0)
print(tup3)
