#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""


"""
'''
2) Create the following data and write to a csv file: 
    Generate 10 random points in each of the the following circles 
    (i) centre at (3,3) and radius 2, (ii) centre at (7,7) and radius 2 (iii) centre at (11,11) and radius 2. 

              (a) Plot the data.

              (b) Using the developed K-means algorithm from problem 1,  
              show the change in the centroid as well as the class assignments. 
              Also, plot the cost function for K varying from 1 to 5. 
              Show that the value of K matches with the intuition from the data. 
              Plot the K-classes for the final K-value.

'''
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
import math
import random
import pandas as pd


class KMeansClustering:
    def __init__(self):
        self.max_iterations = 100 
        self.plot_figure = True 
        
    
    def initialize_random_centroids(self, X):
        centroids = np.zeros((self.K, self.num_features))  
        for k in range(self.K):
            x = np.random.choice(range(self.num_samples))
            centroid = X[np.random.choice(range(self.num_samples))] 
            centroids[k] = centroid
        return centroids 
    
    def create_cluster(self, X, centroids):
        clusters = [[] for i in range(self.K)]
        for point_idx, point in enumerate(X):
            closest_centroid = np.argmin(
                np.sqrt(np.sum((point-centroids)**2, axis=1))
            ) 
            clusters[closest_centroid].append(point_idx)
        return clusters 
    
 
    def calculate_new_centroids(self, cluster, X):
        centroids = np.zeros((self.K, self.num_features)) 
        for idx, cluster in enumerate(cluster):
            new_centroid = np.mean(X[cluster], axis=0) 
            centroids[idx] = new_centroid
        return centroids
    
    
    def predict_cluster(self, clusters):
        y_pred = np.zeros(self.num_samples) 
        for cluster_idx, cluster in enumerate(clusters):
            for sample_idx in cluster:
                y_pred[sample_idx] = cluster_idx
        return y_pred
    
    
    def plot_fig(self, X,y,centroids):
        fig = plt.scatter(X[:, 0], X[:, 1],c=y)
        plt.scatter(centroids[:,0] , centroids[:,1] , s = 80, linewidth=10,color = "red")

        plt.show() 
        
    
    def fit(self, X,num_clusters):
        self.num_samples, self.num_features = X.shape 
        self.K = num_clusters 

        centroids = self.initialize_random_centroids(X) 
        for i in range(self.max_iterations):
            clusters = self.create_cluster(X, centroids) 
            previous_centroids = centroids
            centroids = self.calculate_new_centroids(clusters, X) 
            diff = centroids - previous_centroids 
            if not diff.any():
                break
        y_pred = self.predict_cluster(clusters)
        if self.plot_figure: 
            self.plot_fig(X,y_pred,centroids)  
        return y_pred,centroids,clusters
        
    def findCost(self,data,cluster,centroid,num_clusters):
      cost =0
      for i in range(num_clusters):
        data_chunk = data[cluster[i]]
        cost = cost + np.sqrt(np.sum((data_chunk-centroid[i,:])**2))
        return cost

  
    def uniform(self):
           return random.random();


    def randPoint(self,r, x, y, n):
        res = list();    
        data=np.zeros((n,2))
        for i in range(n):
           theta = 2 * math.pi * self.uniform();      
           len = math.sqrt(self.uniform()) * r;  
           res.append([(x + len * math.cos(theta)), (y + len * math.sin(theta))]);      
           data[i,:]= (x + len * math.cos(theta)), (y + len * math.sin(theta))
     
        return data;  
            
if __name__ == "__main__":
    np.random.seed(10)
   
   
    kmeans = KMeansClustering( )
    data1 = kmeans.randPoint(2,3,3,10)
    data2 = kmeans.randPoint(2,7,7,10)
    data3 = kmeans.randPoint(2,11,11,10)
    data = np.vstack((data1,data2,data3))
    np.random.shuffle(data)
    fig = plt.scatter(data[:,0],data[:,1])
    plt.show()
    df = pd.DataFrame(data,)
 

    df.to_csv("data_P2.csv")

    
    costlist=[]
    for cluster_num in range(1,6):
      y1_pred,centroid1,cluster1 = kmeans.fit(data,cluster_num)  
      cost = kmeans.findCost(data,cluster1,centroid1,cluster_num)
      costlist.append(cost)

    print(costlist)

    plt.plot(range(1,6),costlist)  
    