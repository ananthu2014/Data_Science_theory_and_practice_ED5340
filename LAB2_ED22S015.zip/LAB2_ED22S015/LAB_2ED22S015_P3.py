# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 14:54:04 2022

@author: anant
"""
#continue keyword usage
for i in range(0,9):
    if i==3:
        continue
    print(i)
    
#demonstration of pass
for i in [1,2,3]:
    pass
print(i)

a = 33
b = 200

if b > a:
  pass
else:
    print(a)