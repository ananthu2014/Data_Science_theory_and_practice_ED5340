# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 15:44:55 2022

@author: anant
"""

import math
#exponential function
k=math.e
x=input(('Specify the power of exponential function:'))
x=int(x)
i=1
while i<x:
   k=pow(k,i)
   i+=1
print('The value of exponential function is',k)
 

#sine function 
x= int(input("Enter the value of x: "))
n = int(input("Enter the value of n: "))
sign = -1
fact = i =1
sum = 0
while i<=n:
    p = 1
    fact = 1
    for j in range(1,i+1):
        p = p*x
        fact = fact*j
    sign = -1*sign
    sum = sum + sign* p/fact
    i = i+2
print("sin(",x,") =",sum)  


#cosx

x= int(input("Enter the value of x: "))
n = int(input("Enter the value of n: "))
sign=-1
fact=1
i=2
sum=0
while i<=n:
    p=1
    fact=1
    for j in range(1,i+1):
        p = p*x
        fact = fact*j
    sum= sum + sign* p/fact
    sign = -1*sign
    i = i+2
print("cos(",x,") =",1+sum)















