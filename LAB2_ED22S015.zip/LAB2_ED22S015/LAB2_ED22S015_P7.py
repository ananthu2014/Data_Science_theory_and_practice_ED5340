# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 16:56:18 2022

@author: ananthu2014

"""

bank_accounts=['ananthan','dharani','swapnil']
bank_accounts.sort()

a=input('New bank account:')
pos=0

for i in bank_accounts:
    if i> a:
        pos=bank_accounts.index(i)
        break
res=[]
res=bank_accounts[:pos]+[a]+bank_accounts[pos:]   
print(res)
b=input('Enter the name to be deleted:')
res.remove(b)
print(res)

c=input('Enter the name to be inserted:')
res.insert(0,c)
print(res)

new=[]
for i in res:
    if i not in new:
        new.append(i)
print(new)        

