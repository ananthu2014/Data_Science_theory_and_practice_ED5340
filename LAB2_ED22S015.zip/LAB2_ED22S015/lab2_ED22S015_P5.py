# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 16:28:05 2022

@author: ananthu2014
"""

a=input('enter one word string or digits or combination:')
b=[]
for i in a:
    if i.isnumeric():
        b.append(i)
    else:
        if 65<=ord(i)<=90 or 97<=ord(i)<=122:
            b.append(ord(i))
            
sum=0        
for i in b:
    sum=sum+int(i)
print(sum)

            
    