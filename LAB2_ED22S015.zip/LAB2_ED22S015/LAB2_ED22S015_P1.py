# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 14:15:46 2022

@author: anant
"""

number=input('Enter a natural number:')
number=int(number)
if number==1:
    print('The given number is neither prime nor composite')
if number>1:
    for i in range(2,number):
         if number%i==0:
             print('The given number is not prime number')
             break
    else:
       print('The given number is a prime number')
          
           
                
            