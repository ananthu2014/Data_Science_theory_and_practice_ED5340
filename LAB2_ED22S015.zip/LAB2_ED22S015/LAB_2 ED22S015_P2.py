# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 14:54:03 2022

@author: anant
"""

a=int(input('enter first number:'))
b=int(input('enter second number:'))
c=int(input('enter third number:'))
if a<b and a<c :
    print('the smallest number is:'+str(a))
elif b<a and b<c :
    print('the smallest number is:'+str(b))
else:
    print('the smallest number is:'+str(c))
    
    a=int(input('enter first number:'))
    b=int(input('enter second number:'))
    c=int(input('enter third number:'))
    if a<b<c:
        print(a,' is the smallest number')
    elif b<c:
        print(b, 'is the smallest number')
    else:
        print(c, 'is the smallest number')
        
a=int(input('enter first number:'))
b=int(input('enter second number:'))
c=int(input('enter third number:'))

maxi= a if a>b else b
maxii=maxi if maxi>c else c 
print('the largest number is',maxii)
        