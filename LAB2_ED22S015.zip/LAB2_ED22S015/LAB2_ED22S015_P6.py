# -*- coding: utf-8 -*-
"""
Created on Fri Aug  5 16:40:53 2022

@author: ananthu2014
"""
import random

a=[]
i=1
for i in range(1,10):
  k=random.randint(0,100)
  a.append(k)
  a.sort()
  median=len(a)//2
print(a)
print('Median is:',median)
  
c=a[0:median]
d=a[median:-1]
print(c)
print(d)
  



