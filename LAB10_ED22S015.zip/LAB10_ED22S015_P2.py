#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 20:22:53 2022

@author: ananthu2014
"""
'''# # 2) Using the code developed for problem 1, do the linear regression 
for the univariate problem using the attached data file univariate_linear_regression.csv. 
Plot the cost function (both as surface as well as contour) as well as the best fit line.'''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def eqn_grad_msamples(x,y):
    col=np.ones(x.shape[0])
    data=np.insert(x,0,col,axis=1)
    w=np.random.randn(data.shape[1])
    gradj=np.zeros(len(w))
    loss_var=[]
    for i in range(1000):
         h=data@w
         loss=(np.sum((h-y)**2))/(2*data.shape[1])
         loss_var.append(loss)
         for j in range(len(gradj)):
             gradj[j]=np.dot((h-y),data[:,j])/data.shape[0]
         w=w-(0.01*gradj)
    return loss_var,w

f1=pd.read_csv('univariate_linear_regression.csv')
f=np.array(f1)
#print(data)

x=f[:,0:f.shape[1]-1]
y=f[:,-1]
loss_var,w=eqn_grad_msamples(x,y)
print("The optimised values of the univariate linear regression data set is",w)

plt.plot(loss_var,'ro--')
plt.xlabel("Number of iteration")
plt.ylabel("Loss value")
plt.title("Lose function vs iteration")

def function(x,y,w0,w1):
    col=np.ones(x.shape[0])
    data=np.insert(x,0,col,axis=1)
    w=np.array([w0,w1])
    step1=data@w
    step2=np.sum((y-step1)**2)/(2*data.shape[0])
    return step2

w0=np.linspace(-20,20,1000)
w1=np.linspace(-10,10,1000)
z=np.zeros((1000,1000))
W0,W1=np.meshgrid(w0,w1)
for i in range(len(w1)):
    for j in range(len(w0)):
        z[i,j]=function(x,y,w0[j],w1[i])
plt.figure(figsize=(10,10))
C=plt.contour(W0,W1,z,200)
plt.clabel(C,fontsize=10)
plt.show()

fig=plt.figure(figsize=(10,10))
ax=fig.add_subplot(111,projection='3d')
ax.set_xlabel('W0',size=20)
ax.set_ylabel('W1',size=20)
ax.set_zlabel('J(W0,W2)',size=20)
ax.set_title('Surface_plot of loss function',size=40,color='r')
ax.plot_surface(W0,W1,z,cmap='jet',rstride=10,cstride=5)

plt.show()
plt.scatter(x,y,label='original data')
plt.plot(x,(w[0]+w[1]*x),label='best fit line')
plt.xlabel('input')
plt.ylabel('output')
plt.title("prediction vs groundtruth")
plt.legend()
plt.show()