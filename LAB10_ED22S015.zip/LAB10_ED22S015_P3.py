#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 21:01:57 2022

@author: ananthu2014
"""


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def eqn_grad_msamples(x,y):
    col=np.ones(x.shape[0])
    data=np.insert(x,0,col,axis=1)
    w=np.random.randn(data.shape[1])
    gradj=np.zeros(len(w))
    loss_var=[]
    for i in range(10000):
         h=data@w
         loss=(np.sum((h-y)**2))/(2*data.shape[1])
         loss_var.append(loss)
         for j in range(len(gradj)):
             gradj[j]=np.dot((h-y),data[:,j])/data.shape[0]
         w=w-(0.0001*gradj)
    return loss_var,w

f=pd.read_csv('heart.data.csv')
f=np.array(f)
#print(data)
f=f[:,1:]
x=f[:,0:f.shape[1]-1]
y=f[:,-1]
loss_var,w=eqn_grad_msamples(x,y)
print("The optimised values of the univariate linear regression data set is",w)



x1=x[:,0]
x2=x[:,1]
X1,X2=np.meshgrid(x1,x2)
z=(w[1]*X1)+(w[2]*X2)+w[0]
fig=plt.figure(figsize=(10,10))
ax=fig.add_subplot(111,projection='3d')
ax.set_xlabel('Input1',size=20)
ax.set_ylabel('Input2',size=20)
ax.set_zlabel('Output',size=20)
ax.set_title('Best fit plane',size=40,color='r')
ax.plot_surface(X1,X2,z,cmap='jet',rstride=10,cstride=5)
ax.scatter3D(x1,x2,y,color='red')
plt.show()

plt.scatter(x1,x2,y,color='m')
plt.xlabel('biking')
plt.ylabel("heart disease")
plt.title("Biking vs heart disease",fontsize=20)
print(f"The correlation between biking and heart disease is {np.corrcoef(x[:,0],y)[0,1]}")

plt.show()

plt.scatter(x[:,1],y,color='r')
plt.xlabel('smoking')
plt.ylabel("heart disease")
plt.title("smoking vs heart disease",fontsize=20)
print(f"The correlation between smoking and heart disease is {np.corrcoef(x[:,1],y)[0,1]}")
plt.show()