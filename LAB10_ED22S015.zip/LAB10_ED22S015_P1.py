#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 12:46:06 2022

@author: ananthu2014
"""
'''1) Implement the generalized equation for finding the gradient of m-samples, each having n-features 
(as we discussed in today's class). Also, implement the gradient descent approach
 assuming a constant learning rate '''

import numpy as np
#import pandas as pd

def eqn_grad_msamples(x,y):
    col=np.ones(x.shape[0])
    data=np.insert(x,0,col,axis=1)
    w=np.random.randn(data.shape[1])
    gradj=np.zeros(len(w))
    loss_var=[]
    for i in range(4000):
         h=data@w
         loss=(np.sum((h-y)**2))/(2*data.shape[1])
         loss_var.append(loss)
         for j in range(len(gradj)):
             gradj[j]=np.dot((h-y),data[:,j])/data.shape[0]
         w=w-(0.01*gradj)
    return loss_var,w


