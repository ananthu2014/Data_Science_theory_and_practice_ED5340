# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 15:13:45 2022

@author: anant
"""

metro = {'Mumbai', 'Chennai', 'New Delhi', 'Pune', 'Bangalore', 'Hyderabad'}

coastal = { 'Surat', 'Vizag', 'Chennai', 'Panaji', 'Mumbai', 'Cochin'}

both=[]
for i in metro:
    if i in coastal:
        both.append(i)
print('cities which are coastal and metropolitan are:',both)
metro=list(metro)
coastal=list(coastal)
notboth=[]
for i in coastal:
    if i not in metro:
        notboth.append(i)
for j in metro:
    if j not in coastal:
        notboth.append(j)
print('cities which are either metropolitan or coastal but not both is:',notboth)        