# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 13:41:41 2022

@author: anant
"""

#question 1

students=[]
for i in range(0,3):
    ele=input('enter the name of student:')
    students.append(ele)
print(students)
a=[]
sports=['cricket','football','hockey']
for stud in students:
    like=input('enter the favourite sport(s) among cricket,football,hockey:('+str(stud)+')-')
    a.append(like)
print(a)
dict1 = {k:v for k,v in zip(students,a)}
print('the favourite sports of students are:',dict1)       