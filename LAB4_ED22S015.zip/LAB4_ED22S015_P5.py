# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 17:57:17 2022

@author: anant
"""

import random
str1=['a','b','c','d','e']
A={i:random.randint(0,100) for i in str1}
print(A)
str2=['f','b','e','k','j']
B={i:random.randint(100,200) for i in str2}
print(B)
for k in B.keys():
    if k in A.keys():
        A[k]=A[k]+B[k]
    else:
        A[k]=B[k]
print(A)

print('unique value',set(A.values()))        
        
        
        