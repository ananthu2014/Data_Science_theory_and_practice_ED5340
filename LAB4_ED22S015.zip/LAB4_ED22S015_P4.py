# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 18:13:15 2022

@author: anant
"""

studlist = {'ED22S015' : {'SGPA' : 9.07,'Name' : 'ananthan','CGPA':8.8},
            'ED22S016' : {'SGPA' : 9.12,'Name' : 'dharani','CGPA':6.7},
            'ED22S017' : {'SGPA' : 9.15,'Name' : 'swapnil','CGPA':5.7}}
res = sorted(studlist.items(), key = lambda x: x[1]['CGPA'])
print(res)
studlist.update({'ED22S015' : {'SGPA' : 9.07,'Name' : 'ananthan','CGPA':8.8}})
res2 = sorted(studlist.items(), key = lambda x: x[1]['CGPA'])
print(res2)