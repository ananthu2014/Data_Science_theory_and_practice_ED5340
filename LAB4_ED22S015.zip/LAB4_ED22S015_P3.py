# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 14:15:57 2022

@author: anant
"""

name='ananthakrishnan'
splitted=[char for char in name]
print(splitted)
m = []
for k in splitted:
    if k not in m:
        m.append(k)
print('alphabets present after removing duplicates=',m)
str2=''
for j in m:
    str2=str2+j
print('name after removing duplicates=',str2)
number=[]
for y in str2:
    key=name.count(y)
    number.append(key)   

dict1={i:j for i,j in zip(m,number)}    
print('number of each alphabets in the given string is:',dict1)
dict2={i:j for i,j in zip(m,number) if j==1} 
print('The unique alphabets:',dict2)
first_key = list(dict2.keys())[0]
print('The first unique alphabet is:',first_key)

    