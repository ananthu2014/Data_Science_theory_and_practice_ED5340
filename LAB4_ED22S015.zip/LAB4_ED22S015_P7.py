# -*- coding: utf-8 -*-
"""
Created on Fri Aug 19 16:17:51 2022

@author: anant
"""

  
   
def checklist(lst):
   
   for j in words:
     sorted_word = sorted(j)
     sorted_word = ''.join(sorted_word)
     lst.append(sorted_word)
   print(lst)

   ele = lst[0]
   chk = True
   for item in lst:
     if ele != item:
      chk = False
      break;
   if (chk == True): 
     print("Equal")
   else: print("Not equal") 
   
   
n=int(input('no of elements:'))
words=[]
for i in range(n):
     k=input('elements:')
     words.append(k)
lst=[]
checklist(lst)     
     