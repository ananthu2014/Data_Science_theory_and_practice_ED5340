# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 01:41:45 2022

@author: ananthu2014
"""

#6)Class Containership: We saw the example of Department / Faculty in the class for 
#this one. Add another class called student. Print a few output instances.

class department:
    def __init__(self,dname='enggdesign'):
        self._deptname=dname
        
    def print_dept(self):
            print(self._deptname)
            
class faculty:
    
    def __init__(self,dept,fname='raman',fid=1234):
        self._fname=fname
        self._fid=fid
        self._dobj=department(dept) #OBJECT FROM 'department' class
        
        
    def print_faculty(self):
        print(self._fname,self._fid)
        self._dobj.print_dept()
        
    
            
       
class student:
    
    def __init__(self,dept,sname,sid=15,sem=4):
        self._sname=sname
        self._sid=sid
        self._sem=sem
        self._dobj=department(dept)
        
        
        
    def print_student(self):
         print(' NAME:',self._sname,'\n ID NUMBER:'
               ,self._sid,'\n','SEMESTER:',self._sem)
         self._dobj.print_dept()
         
        

    
    
s1=student('ENGINEERING DESIGN','ananthan',15,4)
s1.print_student() 
    

f1=faculty('ed','raman',12)
f1.print_faculty()

f2=faculty('ed','name1',23)
f3=faculty('me','name2',24)
f4=faculty('bt','name3',45)

#list of faculty
listoffac=[]
listoffac.append(f1)
listoffac.append(f2)
listoffac.append(f3)
listoffac.append(f4)


for each in listoffac:
    each.print_faculty()
    
    
    
    
    
    
    
    
    
    
    
    