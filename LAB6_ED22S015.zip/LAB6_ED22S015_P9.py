# -*- coding: utf-8 -*-
"""

@author: ananthu2014
"""

# Question-9

class Bill:
    def __init__(self,cname = "",tnumber = 0,order = ""):
        self._cname = cname
        self._tnumber = tnumber
        self._order = order

    def getOrderDetails(self):
        orders_list = []
        for o in self._order.split(","):
            item,number = o.split("x")
            orders_list.append((item,int(number)))
        return orders_list
class RestaurantBill(Bill):
    def __init__(self,cname = "",tnumber = 0,order = "",pricelist = ""):
        super().__init__(cname,tnumber,order)
        self._pricelist = pricelist

    def calculatebill(self):
        orders_list = self.getOrderDetails()
        items_list = {}
        for i in self._pricelist.split(","):
            item,price = i.split("-")
            items_list[item] = float(price)
        bill_amt = 0.0
        for order in orders_list:
            item = order[0]
            number = order[1]
            bill_amt += number*items_list[item]
        return bill_amt

    def printBill(self):
        print("======Bill======")
        orders_list = self.getOrderDetails()
        items_list = {}
        for i in self._pricelist.split(","):
            item,price = i.split("-")
            items_list[item] = float(price)
        for order in orders_list:
            item = order[0]
            number = order[1]
            print("Item Name:",item)
            print("Price:",items_list[item])
            print("Quantity:",number)
            print("Amount:",number*items_list[item])
            print()
        print("Total Amount:",self.calculatebill())
        print("5% GST Charges:",round(0.05*self.calculatebill(),3))
        print("5% Service Charges: ",round(0.05*self.calculatebill(),3))
        print("Final Amount Payable:",round(1.1*self.calculatebill(),3))

r = RestaurantBill("Saahil",49,"Chapathix3,Chicken Curryx1,Chicken Fried Ricex1,Lime Juicex1,Banana Milkshakex1","Chapathi-5,Barotta-8,Chicken Curry-70,Chicken Fry-100,Chicken Fried Rice-65,Chicken Noodles-65,Lime Juice-12,Banana Milkshake-27")
r.printBill()
