# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 13:02:34 2022

@author: ananthu2014
"""

class student:
    def __init__(self,n,r):
        self.student_name=n
        self.rollno=r
        
    def get_details(self,n,r):
        self.name=n
        self.student_rollno=r
        
    def print_details(self):
        print('NAME:',self.student_name)
        print("ROLL NUMBER:",self.rollno)
        
class JEE(student):
    def __init__ (self,n,r,phy,che,mat):
        student.__init__(self,n,r)
        self.physics_marks=phy
        self.chemistry_marks=che
        self.maths_marks=mat
        
    def get_marks(self,n,r,phy,che,mat):
        student.__init__(self,n,r)
        self.physics_marks=phy
        self.chemistry_marks=che
        self.maths_marks=mat
   
    def print_details1(self):
        print('NAME:',self.student_name)
        print("ROLL NUMBER:",self.rollno)
        print('PHYSICS MARKS:',self.physics_marks)
        print('CHEMISTRY MARKS:',self.chemistry_marks)
        print('MATHS MARKS:',self.maths_marks)
        
class semester(JEE):
    
    def __init__(self,n,r,phy,che,mat,courses,cgpa):
        JEE.__init__(self,n,r,phy,che,mat)
        self.courseslist=courses
        self.cgpa=cgpa
        
    def get_sem_details(self,n,r,phy,che,mat):
        JEE.__init__(self,n,r,phy,che,mat)
        self.physics_marks=phy
        self.chemistry_marks=che
        self.maths_marks=mat
        
    def print_details3(self):
         print('NAME:',self.student_name)
         print("ROLL NUMBER:",self.rollno)
         print('PHYSICS MARKS:',self.physics_marks)
         print('CHEMISTRY MARKS:',self.chemistry_marks)
         print('MATHS MARKS:',self.maths_marks)
         print('COURSES LIST:',*self.courseslist)
         print('CGPA:',self.cgpa)
         
         
a=JEE('ANANTHAKRISHNAN',22,33,44,55)
a.print_details1()

b=semester('ANANTHAKRISHNAN',22,33,44,55,
           ['Data science','LARP','Data structures'],9.3)
b.print_details3()
         
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        