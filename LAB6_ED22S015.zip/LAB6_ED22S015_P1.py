# -*- coding: utf-8 -*-
"""
ANANTHU2014


"""
#1)

class Complex:
    
    def __init__(self,r=0,im=0):
        self._real=r
        self._imag=im
#Addition of two complex numbers using a method

    def add_comp(self,other):
       #self corresponds to c1 and other corresponds to c2    
       c=Complex()
       c._real=self._real + other._real
       c._imag=self._imag + other._imag
       return c
   
 #subtraction of two complex numbers using a method
   
    def sub_comp(self,other):    
      c=Complex()
      c._real=self._real - other._real
      c._imag=self._imag - other._imag
      return c
  
  #multiplication of two complex numbers using method
  
    def multiplication_comp(self,other):
        c=Complex()
        c._real = (self._real*other._real)-(self._imag*other._imag)
        c._imag = (self._real*other._imag)+(self._imag+other._real)
        return c
    
  #division of two complex numbers using method
    
    def truedivision_comp(self,other):
      c=Complex()
      if other._real or other._imag!=0:
        c._real=((self._real*other._real)+(self._imag*other._imag))/(other._real**2+other._imag**2)
        c._imag= ((self._imag+other._real)-(self._real*other._imag))/(other._real**2+other._imag**2)
        return c
      else:
         c._real='error'
         c._imag='error'
         return c

    def floordivision_comp(self,other):
     if other._real or other._imag!=0:   
      c=Complex()
      c._real=((self._real*other._real)+(self._imag*other._imag))//(other._real**2+other._imag**2)
      c._imag= ((self._imag+other._real)-(self._real*other._imag))//(other._real**2+other._imag**2)
      return c
     else:
       c._real='error'
       c._imag='error'
       return c
    
#Addition and subtraction of two complex numbers with operator overloading

    def __add__(self,other): #operator overloading method
        c=Complex()
        c._real=self._real+other._real
        c._imag=self._imag+other._imag
        return c
    
    def __sub__(self,other1): #operator overloading method
        c=Complex()
        c._real=self._real-other1._real
        c._imag=self._imag-other1._imag
        return c
    
    
#multiplication of two complex numbers operator overloading

    def __mul__(self,other):
      c=Complex()
      c._real = (self._real*other._real)-(self._imag*other._imag)
      c._imag = (self._real*other._imag)+(self._imag+other._real)
      return c
  
#division of two complex numbers using method
  
    def __truediv__(self,other):
      c=Complex()
      if other._real or other._imag!=0:
       c._real=((self._real*other._real)+(self._imag*other._imag))/(other._real**2+other._imag**2)
       c._imag= ((self._imag+other._real)-(self._real*other._imag))/(other._real**2+other._imag**2)
       return c
      else:
          c._real='error'
          c._imag='error'
          return c   

    def __floordiv__(self,other):
     if other._real or other._imag!=0:   
      c=Complex()
      c._real=((self._real*other._real)+(self._imag*other._imag))//(other._real**2+other._imag**2)
      c._imag= ((self._imag+other._real)-(self._real*other._imag))//(other._real**2+other._imag**2)
      return c
     else:
          c._real='error'
          c._imag='error'
          return c   
    
#print function   
    def print_comp(self):
        print('real=',self._real,'imaginary=',self._imag,'complex number=',
              self._real,'+ (i)',self._imag)
        
c1=Complex(4.5,5.45) 
c1.print_comp()
c2=Complex(3.5,8.45)
c2.print_comp()
c3=Complex()
c3.print_comp()
print('\n')

c3=c1+c2 
print('addition using overloading') #operator overloading
c3.print_comp()
print('\n')

c3=c1.add_comp(c2)
print('addition using method') #normal method function calling
c3.print_comp()
print('\n')
c4=Complex()
c4=c1-c2
print('subtraction using overloading')
c4.print_comp()
print('\n')

c5=c1.sub_comp(c2)
print('subtraction using method')
c5.print_comp()
print('\n')

c7=Complex(2,3)
c8=Complex(4,5)
c9=Complex()
print('multiplication using method')
c9=c7.multiplication_comp(c8)
c9.print_comp()
print('\n')

c10=Complex()
c10=c7.truedivision_comp(c8)
print('true division using method')
c10.print_comp()
print('\n')

c11=Complex()
c11=c7.floordivision_comp(c8)
print('floor division using method')
c11.print_comp()
print('\n')

c12=Complex()
c12=c7*c8
print('multiplication using overloading')
c12.print_comp()
print('\n')

c13=Complex()
c13=c7/c8
print('true divison using overloading')
c13.print_comp()
print('\n')

c14=Complex()
c14=c7//c8
print('floor divison using overloading')
c14.print_comp()
print('\n')

c15=Complex(3,4)
c16=Complex(0,0)
c17=c15.truedivision_comp(c16)
print('true divison error case')
c17.print_comp()
print('\n')




