# -*- coding: utf-8 -*-
"""

@author: ananthu2014
"""

#3)Create a class Polygon(),inherit a class Square() from the polygon class, 
#define the length of side of square in parent class(Polygon)using __init__,() 
#and use that in Inherited class, define a method findarea() inside inherited 
#class(Square) which finds area of the square and returns it.

class Polygon:
    def __init__(self,l):
        self.length=l
        
            
class Square(Polygon):
    def __init__(self,l,a=0):
       super().__init__(l)
       
       
    def findarea(self):
        self.area=self.length**2
        

        
    
    def printderived(self):
        print('The area of a square of given side=',self.area)
        
c1=Square(int(input('Enter the length of side:')))
c1.findarea()
c1.printderived()        