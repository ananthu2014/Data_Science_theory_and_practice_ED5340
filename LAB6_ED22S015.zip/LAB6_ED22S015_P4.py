# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 15:48:41 2022

@author: anant
"""
#4)
class Complex:
    
    def __init__(self,r=0,im=0):
        self._real=r
        self._imag=im
        
    def __str__(self):
        sign='+' if self._imag >=0 else ''
        return '{}{}{}i'.format(self._real,sign,self._imag)
    
#Addition of two complex numbers using a method

    def add_comp(self,other):
       #self corresponds to c1 and other corresponds to c2    
       c=Complex()
       c._real=self._real + other._real
       c._imag=self._imag + other._imag
       print('from class Complex')
       return c
   
 #subtraction of two complex numbers using a method
   
    def sub_comp(self,other):    
      c=Complex()
      c._real=self._real - other._real
      c._imag=self._imag - other._imag
      print('Complex class')
      return c
  
  #multiplication of two complex numbers using method
  
    def multiplication_comp(self,other):
        c=Complex()
        c._real = (self._real*other._real)-(self._imag*other._imag)
        c._imag = (self._real*other._imag)+(self._imag+other._real)
        return c
    
  #division of two complex numbers using method
    
    def truedivision_comp(self,other):
      c=Complex()
      if other._real or other._imag!=0:
        c._real=((self._real*other._real)+(self._imag*other._imag))/(other._real**2+other._imag**2)
        c._imag= ((self._imag+other._real)-(self._real*other._imag))/(other._real**2+other._imag**2)
        return c
      else:
         c._real='error'
         c._imag='error'
         return c

    def floordivision_comp(self,other):
     if other._real or other._imag!=0:   
      c=Complex()
      c._real=((self._real*other._real)+(self._imag*other._imag))//(other._real**2+other._imag**2)
      c._imag= ((self._imag+other._real)-(self._real*other._imag))//(other._real**2+other._imag**2)
      return c
     else:
       c._real='error'
       c._imag='error'
       return c
    
#Addition and subtraction of two complex numbers with operator overloading

    def __add__(self,other): #operator overloading method
        c=Complex()
        c._real=self._real+other._real
        c._imag=self._imag+other._imag
        return c
    
    def __sub__(self,other1): #operator overloading method
        c=Complex()
        c._real=self._real-other1._real
        c._imag=self._imag-other1._imag
        return c
    
    
#multiplication of two complex numbers operator overloading

    def __mul__(self,other):
      c=Complex()
      c._real = (self._real*other._real)-(self._imag*other._imag)
      c._imag = (self._real*other._imag)+(self._imag+other._real)
      return c
  
#division of two complex numbers using method
  
    def __truediv__(self,other):
      c=Complex()
      if other._real or other._imag!=0:
       c._real=((self._real*other._real)+(self._imag*other._imag))/(other._real**2+other._imag**2)
       c._imag= ((self._imag+other._real)-(self._real*other._imag))/(other._real**2+other._imag**2)
       return c
      else:
          c._real='error'
          c._imag='error'
          return c   

    def __floordiv__(self,other):
     if other._real or other._imag!=0:   
      c=Complex()
      c._real=((self._real*other._real)+(self._imag*other._imag))//(other._real**2+other._imag**2)
      c._imag= ((self._imag+other._real)-(self._real*other._imag))//(other._real**2+other._imag**2)
      return c
     else:
          c._real='error'
          c._imag='error'
          return c   
    
#print function   
    def print_comp(self):
        print('real=',self._real,'imaginary=',self._imag,'complex number=',
              self._real,'+ i',self._imag)
        
        
#multi level inheritance
class complex1(Complex):
    def __init__(self,r=0,im=0):
        super().__init__(r,im)

    def conjugate(self):
         print('derived conjugate')
         return complex1(self._real,-self._imag)

    def additioninherited(self,other):
         print('derived addition')
         return super().add_comp(other)
          
    def multiinherited(self,other):
        c=complex1()
        c._real=self._real*other._real-self._imag*other._imag
        c._imag=self._real*other._imag + self._imag + other._real
        print('Derived multiplication')
        return c 
    
class complex2(complex1):
  def __init__(self,r=0,im=0):
      super().__init__(r,im)
      
  def add(self,other):
    print('derived class3')
    return super().additioninherited(other)

  def multi(self,other):
       print('derived class3')
       return super().multiinherited(other)
   

r1 = int(input('Enter the 1st real part:'))
im1 = int(input('Enter the 1st imaginary part:'))
r2 = int(input('Enter the 2nd real part:'))
im2 = int(input('Enter the 2nd imaginary part:'))

c1 = complex2(r1,im1)
c2 = complex2(r2,im2)

print('c1 =',c1)
print('c2 =',c2)

print('Addition of complex numbers c1 and c2:',c1.add(c2))
print()
print('Multiplication of complex numbers c1 and c2:',c1.multi(c2))
print()



  
    
  
    
    
    
        







        