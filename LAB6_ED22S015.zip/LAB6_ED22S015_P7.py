# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 02:41:36 2022

@author: ananthu2014
"""
#7)

class department:
    def __init__(self,dname='ENGINEERING DESIGN'):
        self._deptname=dname
        
    def print_dept(self):
            print('DEPARTMENT:',self._deptname)
            
class faculty:
    
    def __init__(self,dept,fname='RAMANATHAN',fid=1234):
        self._fname=fname
        self._fid=fid
        self._dobj=department(dept) #OBJECT FROM 'department' class
        
        
    def print_faculty(self):
        print('FACULTY NAME:',self._fname,'FACULTY ID:',self._fid)
        self._dobj.print_dept()
        
    
class student:
    
    def __init__(self,dept,sname,sid=15,sem=4):
        self._sname=sname
        self._sid=sid
        self._sem=sem
        self._dobj=department(dept)
        
    def print_student(self):
         print(' NAME:',self._sname,'\n ID NUMBER:'
               ,self._sid,'\n','SEMESTER:',self._sem)
         self._dobj.print_dept()
         
        
class Project(department,faculty, student):

    def __init__(self,dname,fname,fid,sname,sid,sem,title = ""):
        department.__init__(self,dname)
        faculty.__init__(self,dname,fname,fid)
        student.__init__(self,dname,sname,sid,sem)
        self._title = title

    def print_details(self):
        print("Department:",self._deptname)
        print("Project Title:",self._title)
        print("Faculty Name:",self._fname)
        print("Faculty ID:",self._fid)
        print("Student Name:",self._sname)
        print("ID Number:",self._sid)
        print("Semester:",self._sem)
        print('\n')
        
p1 = Project('ENGINEERING DESIGN','RAMANATHAN',1234,'ANANTHAKRISHNAN',15,4,'MACHINE LEARNING')
p2 = Project('MECHANICAL','ANUPAM',5678,'HARITHA',23,3,'COMPUTATIONAL GEOMETRY')
p3 = Project('APPLIED MECHANICS','VENKATESH',1334,'VISHNU',14,2,'MECHTRONICS')
p1.print_details()
p2.print_details()
p3.print_details()