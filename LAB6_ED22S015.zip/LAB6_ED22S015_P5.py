# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 21:55:15 2022

@author: ananthu2014
"""
#5)
import random 
from random import randint

class Matrix1:
    def __init__(self,rows,cols):
        self.rows = rows
        self.cols = cols
        self.mat = [[randint(0,10) for j in range(self.cols)] for i in range(self.rows)]

    def __str__(self):
        res = '['
        for i in range(self.rows):
            s = '['
            for j in range(self.cols):
                if j == self.cols - 1:
                    s += str(self.mat[i][j])
                else:
                    s += str(self.mat[i][j]) + ' '
            s += ']'
            res += s

        res += ']'
        return res

    def __add__(self,other):
        print('From the class Matrix 1')
        if self.rows != other.rows or self.cols != other.cols:
            return 'Addition of these matrices is not possible'
        c = Matrix1(self.rows,self.cols)
        c.mat = [[self.mat[i][j] + other.mat[i][j] for j in range(self.cols)] for i in range(self.rows)]
        return c.mat

    def element_mul(self,other):
        print('From the class Matrix 1')    
        if self.rows != other.rows or self.cols != other.cols:
            return 'Element-wise multiplication of these matrices is not possible'
        c = Matrix1(self.rows,self.cols)
        c.mat = [[self.mat[i][j] * other.mat[i][j] for j in range(self.cols)] for i in range(self.rows)]
        return c.mat

class Matrix2(Matrix1):
    def __init__(self, rows, cols):
        super().__init__(rows, cols)

    def add(self,other):
        print('From the class Matrix 2')
        return super().__add__(other)

    def __sub__(self,other):
        print('From the class Matrix 2')
        if self.rows != other.rows or self.cols != other.cols:
            return 'Subtraction of these matrices is not possible'
        c = Matrix2(self.rows,self.cols)
        c.mat = [[self.mat[i][j] - other.mat[i][j] for j in range(self.cols)] for i in range(self.rows)]
        return c.mat

    def __mul__(self,other):
        print('From the class Matrix 2')
        if self.cols != other.rows:
            return 'Mulplication of these matrices is not possible' 
        c = Matrix2(self.rows,self.cols)
        c.mat = [[0 for _ in range(other.cols)] for _ in range(self.rows)]
        for i in range(self.rows):
            for j in range(other.cols):
                for k in range(other.rows):
                    c.mat[i][j] += self.mat[i][k] * other.mat[k][j]
        return c.mat

class Matrix3(Matrix2):
    def __init__(self, rows, cols):
        super().__init__(rows, cols)

    def mat_mul(self,other):
        print('From the class Matrix 3')
        return super().__mul__(other)

    def ele_wise_multiply(self,other):
        print('From the class Matrix 3')
        return super().element_mul(other)
    
    def scalar_mul(self,k):
        print('From the class Matrix 3')
        self.mat = [[k*self.mat[i][j] for j in range(self.cols)] for i in range(self.rows)]
        return self.mat

r1 = int(input('Number of rows of matrix 1'))
c1 = int(input('Number of columns of matrix 1'))
r2 = int(input('Number of rows of matrix 2'))
c2 = int(input('Number of columns of matrix 2')) 
k = int(input('Scalar:'))

m1 = Matrix3(r1,c1)
m2 = Matrix3(r2,c2)

print('m1 =',m1)
print('m2 =',m2)

print()
print('Addition of two matrices m1 and m2:',m1+m2)
print()
print('Subtraction of two matrices m1 and m2:',m1-m2)
print()
print('Multiplication of two matrices m1 and m2:',m1.mat_mul(m2))
print()
print('Element-wise multiplication of two matrices m1 and m2:',m1.element_mul(m2))
print()
print('Scalar multplication of k with matrix m1 is:',m1.scalar_mul(k))
print()
print('Element-wise multiplication of two matrices m2 and m1:',m2.ele_wise_multiply(m1))







 