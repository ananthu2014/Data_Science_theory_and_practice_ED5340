# -*- coding: utf-8 -*-
"""
Created on Fri Sep 16 03:38:54 2022

@author: anant
"""
 #8)Create a class Father with attributes
 
 
 
class Father:
    
    def __init__(self,fname,fage,ftal):
        self._namef=fname
        self._agef=fage
        self._talentsf=ftal
        
    def printoutf(self):
       print('NAME:',self._namef)
       print('AGE:',self._agef)
       print('TALENTS:',self._talentsf)
        
class Mother:
    
    def __init__(self,mname,mage,mtal):
        self._namem=mname
        self._agem=mage
        self._talentsm=mtal
        
    def printoutm(self):
       print('NAME:',self._namem)
       print('AGE:',self._agem)
       print('TALENTS:',self._talentsm)        


class Child(Father,Mother):
    def __init__(self,fname,fage,ftal,mname,mage,mtal):
        print(fname,fage,ftal)
        Father.__init__(self,fname,fage,ftal)
        Mother.__init__(self,mname,mage,mtal)

    def childdetails(self):
        self._child_name=input('Enter name of child:')
        self._child_age=input('Enter age:')
        self._child_gender=input('Enter gender:')
        
    def printoutc(self):
        print("Child's Name:",self._child_name)
        print("Child's Age",self._child_age)
        print("Child's gender:",self._child_gender)
        print("Father's name:",self._namef)
        print("Father's age:",self._agef)
        print("Father's talents:",*(self._talentsf))
        print("Mother's name:",self._namem)
        print("Mother's age:",self._agem)
        print("Mother's talents:",*(self._talentsm))

    def inheritedtalents(self):
        print(self._child_name+"'s talents are:")
        for talent in self._talentsf:
            if(talent in self._talentsm):
                print(talent)

a=Father('Aravindakshan',59,{'painting','cricket','chess'})
#a.printoutf()
b=Mother('Suneethi',51,{'chess','dance','painting'})
#b.printoutm()
c=Child('Aravindakshan',59,{'painting','cricket','chess'},'Suneethi',51,
        {'chess','dance','painting'})
c.childdetails()
c.printoutc()
c.inheritedtalents()
    