# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""

#2)Do the above using CSV reader

import csv 
    
# field names 
fields = ['Students', 'Marks'] 
    
# data rows of csv file 
mark_lst = [ ['Ananthan', '23'], 
         ['Swapnil', '22'], 
         ['Haritha', '25'], 
         ['Minu', '26'], 
         ['Dharani', '27'], 
        ] 
    
filename = "student_marks.csv"

with open(filename, 'w') as csvfile: 
    csvwriter = csv.writer(csvfile) 
    csvwriter.writerow(fields) 
    csvwriter.writerows(mark_lst)