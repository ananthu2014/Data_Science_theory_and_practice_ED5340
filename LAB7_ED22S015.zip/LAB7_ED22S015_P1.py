# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""

#1) Generate a csv file as .txt consisting of the following columns
# - Students and marks. Populate them with at least five rows of data.\
    
msg1='Student     Marks\n'
msg2='Ananthan       23\n'
msg3='Swapnil        22\n'
msg4='Haritha        25\n'
msg5='Minu           26\n'
msg6='Dharani        27\n'


f = open('studentmarks.txt','w')
f.write(msg1)
f.write(msg2)
f.write(msg3)
f.write(msg4)
f.write(msg5)
f.write(msg6)
f.close()    

#alternative method
import csv
  
mark_list=[['STUDENT','MARKS'],['ANANTHAN',10],['SWAPNIL',20],['DHARANI',30],['MINU',40],['HARITHA',50]]
with open('mark_data.csv','w') as file:
    writer=csv.writer(file)
    writer.writerows(mark_list)