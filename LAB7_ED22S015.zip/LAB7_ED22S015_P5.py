# -*- coding: utf-8 -*-
"""

@author: ananthu2014
"""
import pandas as pd
#5) Do the Q.1 using Pandas (create a CSV file on your own)

name = ['Ananthan', 'Swapnil', 'Dharani', 'Haritha', 'Minu']
marks= [16,17,18,19,20] 
dict = {'Name': name, 'Marks':marks} 
     
df = pd.DataFrame(dict)
df.to_csv('Stud_Marks.csv')