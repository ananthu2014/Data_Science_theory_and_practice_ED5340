# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""
#3)For the restaurant Bill in the last lab - take name, table no, order 
#details from a file, price list from another file and print the whole bill 
#to new file.

import csv
price_list = [['Item','Price'],['Roti','28'],['Rice','35'],['Curd Rice','12'],['Vegan','120'],['Non-vegan','150'],['Mango juice','18'],['Fish Curry','130'],['Water','20']]
orders = [['Name','Table No.','Order'],['Swapnil','2','Roti'],['Swapnil','2','Fish Curry'],['Swapnil','2','Mango juice'],['Dharni','6','Rice'],['Dharni','6','Curd Rice'],['Ananth','7','Non-vegan']]
with open('order_details.txt',mode = 'w') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerows(orders)

with open('price_list.txt',mode = 'w') as csv_file:
    writer= csv.writer(csv_file)
    writer.writerows(price_list)
    

price_list = [['Item','Price'],['Roti','28'],['Rice','35'],['Curd Rice','12'],['Vegan','120'],['Non-vegan','150'],['Mango juice','18'],['Fish Curry','130'],['Water','20']]
orders = [['Name','Table No.','Order'],['Swapnil','2','Roti'],['Swapnil','2','Fish Curry'],['Swapnil','2','Mango juice'],['Dharni','6','Rice'],['Dharni','6','Curd Rice'],['Ananth','7','Non-vegan']]
d1 = dict(price_list)
d2 = {}
bill_list = [[i[0],int(d1[i[2]])] for i in orders[1:]]
for i in bill_list:
    if i[0] in d2:
        d2[i[0]] += i[1]
    else:
        d2[i[0]] = i[1]

d2 = list(d2.items())

with open('bills.txt',mode = 'w') as csv_file:
    writer = csv.writer(csv_file)
    writer.writerow(['Name','Total bill'])
    writer.writerows(d2)