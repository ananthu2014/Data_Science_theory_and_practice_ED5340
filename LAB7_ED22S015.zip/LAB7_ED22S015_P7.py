# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""
#7) Using plotting to create functions sin x, and other at least two more functions

import numpy as np
import matplotlib.pyplot as plt

#parabolic graph
x=np.linspace(-5,5,10)
y=x**2
print(y)
plt.plot(x, y)
plt.xlabel('x - axis')
plt.ylabel('y - axis')
plt.title('Parabola')
plt.show()

#graph of sinx
x=np.linspace(-np.pi,np.pi,10)
y=np.sin(x)
print(y)
plt.plot(x, y)
plt.xlabel('x - axis')
plt.ylabel('y - axis')
plt.title('Sinusoidal curve')
plt.show()

#exponential graph
x=np.arange(-10,10,0.4)
y=10**x
print(y)
plt.plot(x, y)
plt.xlabel('x - axis')
plt.ylabel('y - axis')
plt.title('Exponential Graph')
plt.show()