# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 23:23:34 2022

@author: ananthu2014
"""

#8) Any surface and then their corresponding contour plots. 
#Do it for other models other than what is there in the code. 

import matplotlib.pyplot as plt
import numpy as np


x = np.arange(5.0, 15.0, 0.01)
y = np.arange(5.0, 15.0, 0.01)
X,Y=np.meshgrid(x,y)
Z = (X) +  + (Y**2)
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.plot_surface(X, Y, Z,color='blue')

ax.set_xlabel('X values')
ax.set_ylabel('Y values')
ax.set_zlabel('Z values')
ax.set_title('DEMONSTRATION OF SURFACE PLOTTING')

plt.show()


cp  = plt.contour(x, y, Z)
plt.clabel(cp, fontsize=8)
ax.set_xlabel('X VALUES')
ax.set_ylabel('Y VALUES')
ax.set_zlabel('Z VALUES')
ax.set_title('DEMONSTRATION OF CONTOURS')
plt.show()

#alternative method


import numpy as np
import matplotlib.pyplot as plt
#from mpl_toolkits.mplot3d import Axes3D
  
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
  
a, b = np.meshgrid(a, b)
  
# surface plot for a + b
fig = plt.figure()
axes = fig.gca(projection ='3d')
axes.plot_surface(a, b, a + b)
plt.show()


  
a = np.array([1, 2, 3])
b = np.array([4, 5, 6])
  
a, b = np.meshgrid(a, b)
  
# surface plot for a + b
fig = plt.figure()
axes = fig.gca(projection ='3d')
axes.contour(a, b, a + b)
  
plt.show()