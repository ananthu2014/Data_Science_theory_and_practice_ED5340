# -*- coding: utf-8 -*-
"""


@author: ananthu2014
"""

#6) Using Numpy, demonstrate vector and matrix operations.

import numpy as np

#1d array
arr=np.array([1,2,3,4,5])
print(id(arr[0]))
print(arr.itemsize,arr.strides) #itemsize is 4 bytes:memory efficient
print(type(arr))
for i in range(0,len(arr)):
    print(i,arr[i],id(arr[i]))
print('\n')  
arr1=np.array([(1,2,3,4,5),(6,7,7,8,3)])
print(arr1.itemsize,arr1.strides)
for i in range(0,len(arr1)):
    print(i,arr1[i])
print(arr1)

a=np.array(42)
b=np.array([1,2,3,4,5])
c=np.array([[1,2,3,4,5],[3,5,6,3,5],[1,5,2,5,7]])
d=np.array([[2,4,4,4,4],[1,4,6,2,4]])
print(a.ndim,a.shape,a.size,a.dtype,a.itemsize,a.data)
print(b.ndim,b.shape,b.size,b.dtype,b.itemsize,b.data)
print(c.ndim,c.shape,c.size,c.dtype,c.itemsize,c.data)

e=np.arange(15).reshape(3,5)
print(e)

for i in range(len(b)): #printing 1D array
    print(b[i])
print('\n')    
    
for i in range(len(d)): #printing 2d array with 2 for loops
    for j in d[i]:
        print(j)
print('\n')        
    
for i in range(len(d)):
    for j in range(len(d[0])):
        print(d[i][j])
print('\n')        
        
print(d[i][j] for i in range(len(d)) for j in range(len(d[0])))     #?   
    
print(d[1][-1])
print(b[1:3]) #slicing

#using zeroes and ones
zeros=np.zeros((3,5))
print('\n',zeros)

ones=np.ones((2,3,4))
print(ones)

empty=np.empty((4,6))
print(empty)

#arange in array
ran=np.arange(1,5,0.5)
print(ran,type(ran))

from numpy import pi
x=np.linspace(0,2,9)
print(x)
x=np.linspace(0,2*pi,100)
print(x)
y=np.sin(x) #no need of for loop;iterates automatically
print(y)
print('\n')

#using reshape
b=np.arange(10).reshape(2,5)
print(b)

c=np.arange(24).reshape(2,3,4)
print(c)

#basic operators

a=np.array([[1,2],[3,4]])
b=np.array([[1,2],[3,4]])
print(a*b)#element wise multiplication
print(a@b)#matrix multiplication
print(np.dot(a,b)) #dot product multiplication
print(a.dot(b)) #dot product

a=np.array([1,2,3,4])
b=np.arange(4)
print(b)
print(a-b)
print(b**2)
print(np.sin(a))

# Determinant
import numpy as np
a = np.array([[2, 2, 1],
               [1, 3, 1],
               [1, 2, 2]])
print("a = ")
print(a)
det = np.linalg.det(a)
print("\nDeterminant:", np.round(det))