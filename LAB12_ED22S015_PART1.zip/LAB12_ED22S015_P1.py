#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""



"""


'''
1) Split the linear regression (for single variable data given in one of the previous labs) 
in 70 / 30 as train / test data. (you can use either an directly 70% split or randomize it).

          (a) Determine the error in the test data without the regularization parameter. 
          (you can use your existing code for this)

          (b) Determine the error in the test data with the regularization parameter. 
          (this would require developing new code!)
          '''

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import train_test_split

def training(x,y):
    col=np.ones(x.shape[0])
    data=np.insert(x,0,col,axis=1)
    w=np.random.randint(1,10,data.shape[1])
    gradj=np.zeros(len(w))
    loss_var=[]
    for i in range(1000):
         h=data@w
         loss=(np.sum((h-y)**2))/(2*data.shape[0])
         loss_var.append(loss)
         for j in range(len(gradj)):
             gradj[j]=np.dot((h-y),data[:,j])/data.shape[0]
         w=w-(0.01*gradj)
 
    return loss_var,w
def predict(x_test,y_test,w):
    col=np.ones(x_test.shape[0])
    data=np.insert(x_test,0,col,axis=1) 
    h=data@w
    loss=np.sqrt((np.sum((h-y_test)**2))/(data.shape[0]))  
    return loss
f1=pd.read_csv('univariate_linear_regression.csv')
f=np.array(f1)

x=f[:,0:f.shape[1]-1]
y=f[:,-1]
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3,random_state=0)

loss_var,w=training(x_train,y_train)
print("Optimised weight values",w)

loss_test=predict(x_test,y_test,w)


print("Error in the test data:",loss_test)

'''(b) Determine the error in the test data with the regularization parameter. (
          this would require developing new code!)'''


def training_reg(x,y):
    w=np.random.randint(1,10,x.shape[1])
    w0=0
    for i in range(5000):
        h=np.dot(x,w)+w0
        loss=(np.sum((h-y)**2))/(2*x.shape[1])
        dw=np.sum(np.dot(x.T,h-y)+0.5*w)*(1/x.shape[0])
        dw0=np.sum(h-y)*(1/x.shape[0])
        w=w-(0.01*dw)
        w0=w0-(0.01*dw0)
        
  
    return w,w0

def predict_reg(x_test,y_test,w):
    col=np.ones(x_test.shape[0])
    data=np.insert(x_test,0,col,axis=1)  
    h=data@w
    loss=np.sqrt((np.sum((h-y_test)**2))/(data.shape[0]))  
    return loss


f1=pd.read_csv('univariate_linear_regression.csv')
f=np.array(f1)

x=f[:,0:f.shape[1]-1]
y=f[:,-1]
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3,random_state=0)
w,w0=training_reg(x_train,y_train)
w=np.array([w0,w])
print("optimised weight value with regularisation",w)

loss_test=predict_reg(x_test,y_test,w)

print("Error in the test data with regularisation:",loss_test)