# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:38:49 2022

@author:ananthakrishnan
"""

#8

#(a)
def minimum(L):
    if len(L) == 1:
        return L[0]
    else:
        return min(L[0],minimum(L[1:]))

L= [5,3,8,9,3,1,5,7,8,2,0]
print(minimum(L))


#(b)
def maximum(L):
    if len(L) == 1:
        return L[0]
    else:
        return max(L[0],maximum(L[1:]))

L= [5,3,8,9,3,1,5,7,8,2,0]
print(maximum(L))


