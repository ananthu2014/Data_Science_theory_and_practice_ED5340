# # -*- coding: utf-8 -*-
# """
# Created on Fri Aug 26 13:36:50 2022

# @author:ananthakrishnan
# """
# '''
#9


lst = list(map(int,input('enter:').split()))
s = len(lst)
def summ(l,s):
    if s == 0:
        return 0

    return l[s-1] + summ(l,s-1)

def ascending_order(l):
    if len(l) <= 1:
        return l
    else:
        return (ascending_order([el for el in l[1:] if el <= l[0]]) + [l[0]] + ascending_order([el for el in l[1:] if el > l[0]]))

print('The sum of elements:',summ(lst,s))
print()
print('ascending order of elements:',ascending_order(lst))


