# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:44:34 2022

@author: ananthakrishnan
"""
#6

def cities(s):
    return s[0] == "Z"

city = ["Calicut", "Ernakulam", "Bangalore", "Chennai", "Hyderabad","Indore","Delhi"]
maping = map(cities, city)

print(list(maping))

#Demonstration of Filter()
def cities(s):
    return s[0] == "Z"

cities1 = ["Calicut", "Chennai", "Patna", "Gaziabad", "Gorakhapur"]
filtering = filter(cities, city)

print(list(filtering))

#Demonstrion of Reduce
from functools import reduce

def sum_(x,y):
    return x + y

list1 = [2, 4, -7, 3]
print(reduce(sum_, list1))