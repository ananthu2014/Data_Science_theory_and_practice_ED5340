# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:43:02 2022

@author: ananthakrishnan
"""



# 7

N,M = tuple(map(int,input().split()))
numb = list(range(N+1))
output = ''
for i in numb:
    output += str(i)
print('count is:',output.count(str(M)))