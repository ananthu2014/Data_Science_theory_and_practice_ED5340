# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:50:01 2022

@author: ananthakrishnan
"""

#1


def pascals_triangle(k):
   for i in range(k+1):
      for j in range(k-i):
         print(' ', end='')

      C = 1
      for j in range(1, i+1):
         print(C, ' ', sep='', end='')
         C = C * (i - j) // j
      print()

k = 3
pascals_triangle(k)

  