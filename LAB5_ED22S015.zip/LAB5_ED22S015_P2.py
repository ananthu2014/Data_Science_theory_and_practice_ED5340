# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:49:25 2022

@author:ananthakrishnan
"""

#2

#a) factorial of a user input 
#using recursion
def factorial1(num):
    if num<=1:
        return 1
    else:
        fact = num * factorial1(num-1) 
        return fact

fact = factorial1(6)
print(fact)

#Using loop
num = int(input("enter a number: ")) 
fact = 1
for i in range(1, num + 1):
    fact = fact * i
print("factorial of ", num, " is ", fact)

#b) fibonacci series
#Using Recursion      
def fibonacci_series(n):
    if(n <= 1):
        return n
    else:
        return(fibonacci_series(n-1) + fibonacci_series(n-2))
n = int(input("Enter number of terms:"))
print("Fibonacci sequence is:")
for i in range(n):
    print(fibonacci_series(i))
       
#Using Loops
Number = int(input("\nPlease Enter the Range : "))
a = 0
b = 1
for Num in range(0, Number):
    if(Num <= 1):
        Next = Num
    else:
        Next = a + b
        a = b
        b = Next
    print(Next)