# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:48:42 2022

@author: ananthakrishnan
"""

#3
def f(x,n):
    y = x**n
    return y
x = int(input())
n = int(input())
print('Enter x',x)
print('Enter n',n)
print(f(x,n))


