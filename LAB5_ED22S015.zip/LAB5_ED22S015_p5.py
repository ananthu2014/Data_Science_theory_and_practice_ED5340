# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 13:46:32 2022

@author: ananthakrishnan
"""


#5

sentence = input("enter sentence:")
condtion_asked = input('enter condition:')
def reversing(sentence,condtion_asked):
    if condtion_asked == 'Sentence':
        sentence = sentence[::-1]
        return sentence
    if condtion_asked == 'Words':
        sentence = [i[::-1] for i in sentence.split()]
        return ' '.join(sentence)

def reverse_recur(sentence,condtion_asked):
    if len(sentence) == 1:
        return sentence[0]
    if condtion_asked == 'Sentence':
        return sentence[-1] + reverse_recur(sentence[:-1],condtion_asked)
    elif condtion_asked == 'Words':
        ans = ''
        for i in sentence.split():
            ans += reverse_recur(i,'Sentence') + ' '
        return ans

print('Action of reversing using if or withour recursion:',reversing(sentence,condtion_asked))
print('Action of reversing using recursion:',reverse_recur(sentence,condtion_asked))
    