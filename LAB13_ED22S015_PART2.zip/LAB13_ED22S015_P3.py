#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""



"""


'''
3) Taking any two classes from the above data, add labels to them (0 or 1) and 
create a new csv file. Split the data into Train / Test set as 70/30. 

(a) Plot the decision boundary using the developed logistic regression code 
(either with or without regularization) from one of your previous labs.

(b) Evaluate the metrics such as Precision, Recall, F1-Score and Accuracy on the test data. 
'''



import random
import math
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
import pandas as pd
from sklearn.model_selection import train_test_split
def create_circle(radius,center,number):
    np.random.seed(10)
    data=np.zeros((number,2))
    for i in range(number):
        alpha = 2 * math.pi * random.random()
        r = radius * math.sqrt(random.random())
        x = r * math.cos(alpha) + center[0]
        y = r * math.sin(alpha) + center[1]
        data[i,:]=x,y
    return data
    

class logistic_regression():
    def __init__(self,X,learning_rate=.1,num_iter=10000):
        self.data=X
        self.lr=learning_rate
        self.iter=num_iter
        self.m=X.shape[0]
        self.n=X.shape[1]
    def training(self,X,y):
        self.w=np.random.randn(self.n,1)
        self.b=np.random.randn(1)
        for i in range(self.iter):
            yhat=np.dot(X,self.w)+self.b
            h=self.sigmoid(yhat)
            loss=(-1/self.m)*(np.sum(y*np.log10(h)+(1-y)*np.log10(1-h)))
            dw=np.dot(X.T,h-y)*(1/self.m)
            db=np.sum(h-y)*(1/self.m)
            self.w=self.w-(self.lr*dw)
            self.b=self.b-(self.lr*db)
            if i%1000==0:
                print(f"The loss after {i} iteration is {loss}")
        return self.w,self.b
    def predict(self,X):
        yhat=self.sigmoid(np.dot(X,self.w)+self.b)
        yhat_class=yhat>.5
        return yhat_class
    def sigmoid(self,z):
        val=np.exp(-z)
        return 1/(1+val)



number_=100
np.random.seed(12)
dataA=np.zeros((number_,3))
dataB=np.zeros((number_,3))
data1=create_circle(radius=2,center=(3,3),number=number_)
dataA[:,0:2]=data1
dataA[:,2]=np.zeros(number_)
data2=create_circle(radius=2,center=(7,7),number=number_)
dataB[:,0:2]=data2
dataB[:,2]=np.ones(number_)
data=np.vstack((dataA,dataB))
np.random.shuffle(data)
df=pd.DataFrame(data,columns=['X1','X2','Y'])
df.to_csv('cluster_part2.csv',index=False)


df=np.array(df)
X=df[:,0:2]
Y=df[:,-1]
Y=Y[:,np.newaxis]
x_train,x_test,y_train,y_test=train_test_split(X,Y,test_size=.3,random_state=123,shuffle=True)
lr=logistic_regression(x_train,learning_rate=.1,num_iter=10000)
w,b=lr.training(x_train,y_train)


y_hat=lr.predict(X)
plt.figure(figsize=(10,5))
plt.scatter(X[:,0],X[:,1],s=50,c=np.squeeze(y_hat),cmap='jet',marker='*')
c=-(b/w[1])
m=-(w[0]/w[1])
new_x=np.array([X[:,0].min(),X[:,1].max()])
ymin,ymax=X[:,1].min(),X[:,1].max()
y1=m*new_x+c
plt.fill_between(new_x,[ymin,ymin] , y1, color='tab:orange', alpha=0.2)
plt.fill_between(new_x, [ymax,ymax], y1, color='tab:blue', alpha=0.2)
plt.plot(new_x,y1,'r')
plt.xlabel("feature1",fontsize=15)
plt.ylabel("feature2",fontsize=15)
plt.title("Decision boundary plot",fontsize=25,color='green')
plt.ylim(X[:,1].min(),X[:,1].max())




TP,TN,FP,FN=0,0,0,0
y_hat=lr.predict(x_test)

for i in range(len(y_hat)):
    if y_hat[i]==y_test[i]:
        if y_hat[i]==1:
            TP+=1
        else:
            TN+=1
    else:
        if y_hat[i]==1:
            FP+=1
        else:
            FN+=1
precision=TP/(TP+FP)
recall=TP/(TP+FN)
print(f"The Precision of the model is {precision}")
print(f"The Recall of the model is {recall}")
print(f"The F1 score of the model is {2*(precision*recall)/(precision+recall)}")
accuracy=np.sum(y_hat==y_test)/len(x_test)
print(f"The accuracy of the model is {accuracy*100}")      

